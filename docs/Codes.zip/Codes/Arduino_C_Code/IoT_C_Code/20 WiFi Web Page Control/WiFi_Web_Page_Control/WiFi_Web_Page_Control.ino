/*
 * 名称    : WiFi Web Page Control  
 * 功能    : WIFI 网页控制多个元器件和模块模拟WiFi智能生活
 * 编译 IDE: ARDUINO 2.3.3
 * 作者    : https://www.keyestudio.com/
*/
#include <Arduino.h>
#include <WiFi.h>
#include <ESPmDNS.h>
#include <ESP32Servo.h>
#include <WiFiClient.h>

/*REPLACE WITH YOUR NETWORK CREDENTIALS(Put your SSID & Password)*/
const char* ssid = "OPPO_A55_5G";  //Enter SSID here
const char* password = "773yu2r4"; //Enter Password here
int keyIndex = 0;         // 您的网络密钥索引号(仅 WEP 需要)
int val = 0;

const int ledPins[] = {19, 23, 5};  // 依次定义红、绿、蓝的引脚
const byte chns[] = {0, 1, 2};     // 定义PWM通道
int red, green, blue;

int LEDC_CHANNEL_4 = 4; // LEDC定时器采用通道4
int LEDC_TIMER_13_BIT = 8; // LEDC定时器采用8位精度
const int pasbuzzPin = 26; // 定义无源蜂鸣器引脚为IO26
// 创建一个音乐旋律列表
int melody[] = {330,330,330,262,330,392,196,262,196,165,220,247,233,220,196,330,392,440,349,392,330,262,294,247,262,196,165,220,247,233,220,196,330,392,440,349,392,330,262,294,247,392,370,330,311,330,208,220,262,220,262,294,392,370,330,311,330,523,523,523,392,370,330,311,330,208,220,262,220,262,294,311,294,262,262,262,262,262,294,330,262,220,196,262,262,262,262,294,330,262,262,262,262,294,330,262,220,196};
// 创建一个音调持续时间列表
int noteDurations[] = {8,4,4,8,4,2,2,3,3,3,4,4,8,4,8,8,8,4,8,4,3,8,8,3,3,3,3,4,4,8,4,8,8,8,4,8,4,3,8,8,2,8,8,8,4,4,8,8,4,8,8,3,8,8,8,4,4,4,8,2,8,8,8,4,4,8,8,4,8,8,3,3,3,1,8,4,4,8,4,8,4,8,2,8,4,4,8,4,1,8,4,4,8,4,8,4,8,2};

const int actbuzzPin = 18;   // 定义有源蜂鸣器引脚为IO18
const int motoraPin = 4;   // 定义直流电机IN+的数字控制引脚为IO4
const int motorbPin = 2;   // 定义直流电机IN-的数字控制引脚为IO2
const int relayPin = 35;  // 定义继电器引脚为IO35
const int servoPin = 12;  // 定义舵机引脚为IO12
Servo myservo;  // 创建舵机对象来控制舵机
// Define the minimum and maximum pulse widths for the servo
const int minPulseWidth = 500; // 0.5 ms
const int maxPulseWidth = 2500; // 2.5 ms

int status = WL_IDLE_STATUS;
WiFiServer server(80);

void setup() {
  Serial.begin(115200);  // 初始化硬件串口
  for (int i = 0; i < 3; i++) {   //设置pwm通道，1KHz,8bit
    ledcSetup(chns[i], 1000, 8);
    ledcAttachPin(ledPins[i], chns[i]);
  }
  pinMode(motoraPin, OUTPUT);  // 设置直流电机的IN+引脚为输出模式
  pinMode(motorbPin, OUTPUT);  // 设置直流电机的IN-引脚为输出模式
  pinMode(relayPin, OUTPUT);   // 设置继电器引脚为输出模式
  pinMode(actbuzzPin, OUTPUT);  // 设置有源蜂鸣器引脚为输出模式
  pinMode(pasbuzzPin, OUTPUT);  // 设置无源蜂鸣器引脚为输出模式

  myservo.attach(servoPin);  //设置舵机引脚为IO12
  myservo.write(0); //旋转到0度
  delay(1000); //延迟1s

  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  // Print the ESP32's IP address
  Serial.print("ESP32 Web Server's IP address: ");
  Serial.println(WiFi.localIP());
  Serial.println("TCP server started");
  MDNS.addService("http", "tcp", 80);
}

void loop() {
  WiFiClient client = server.available();   // 实时监听即将到来的客户端
  if (client) {                             // 如果你监听到客户端的话,
    Serial.println("new client");           // 在串口上打印一条消息
    String currentLine = "";                // 创建一个字符串来保存从客户端传入的数据
    while (client.connected()) {            // 在客户端连接时循环
      if (client.available()) {             // 如果有字节需要从客户端读取,
        char c = client.read();             // 读取一个字节，然后
        Serial.write(c);                    // 打印到串行监视器上
        if (c == '\n') {                    // 如果字节是换行符

          // 如果当前行为空，则一行中有两个换行符.
          // 这是客户端HTTP请求的结束，因此发送一个响应:
          if (currentLine.length() == 0) {
            // HTTP首部总是以响应代码开始 (e.g. HTTP/1.1 200 OK)
            // 以及一个内容类型，以便客户端知道将要发生什么，然后是一个空行:
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println();

            // HTTP响应的内容跟在首部之后:
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/A\">here</a> turn on Relay<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/B\">here</a> turn off Relay<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/C\">here</a> turn on RGB<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/D\">here</a> turn off RGB<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/E\">here</a> turn on fan<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/F\">here</a> turn off fan<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/G\">here</a> turn on Actbuzz<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/H\">here</a> turn off Actbuzz<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/I\">here</a> turn on Pasbuzz<br></p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/J\">here</a> <br>servo turn to 180</p>");
            client.print("<p style=\"font-size:7vw;\">Click <a href=\"/K\">here</a> <br>servo turn to 0</p>");
           
            // HTTP响应以另一个空行结束:
            client.println();
            // 跳出while循环:
            break;
          } else {    // 如果有换行符，清除currentLine:
            currentLine = "";
          }
        } else if (c != '\r') {  // 如果你有除回车字符以外的其他字符,
          currentLine += c;      // 并且将其添加到currentLine的末尾
        }

        // 检查客户端请求是否存在 "GET /A"or"GET /B"or"GET /C"or"GET /D"or"GET /E"or"GET /F"or"GET /G"or"GET /H"or"GET /I"or"GET /J"or"GET /K":
        if (currentLine.endsWith("GET /A")) {    // GET /A 打开继电器
          digitalWrite(relayPin, HIGH);       
        }
        if (currentLine.endsWith("GET /B")) {    // GET /B 关闭继电器
          digitalWrite(relayPin, LOW); 
        }
        if (currentLine.endsWith("GET /C")) {    // GET /C 打开RGB
            // Cycle through basic colors
          setColor(255, 0, 0);  // Red
          delay(1000);       // Wait for 1 second
          setColor(0, 255, 0);  // Green
          delay(1000);       // Wait for 1 second
          setColor(0, 0, 255);  // Blue
          delay(1000);       // Wait for 1 second

            // Cycle through blended colors
          setColor(255, 0, 252);  // Magenta
          delay(1000);         // Wait for 1 second
          setColor(237, 109, 0);  // Orange
          delay(1000);         // Wait for 1 second
          setColor(255, 215, 0);  // Yellow
          delay(1000);         // Wait for 1 second
          setColor(34, 139, 34);  // Forest Green
          delay(1000);         // Wait for 1 second
          setColor(0, 112, 255);  // Light Blue
          delay(1000);         // Wait for 1 second
          setColor(0, 46, 90);    // Indigo
          delay(1000);         // Wait for 1 second
          setColor(128, 0, 128);  // Purple
          delay(1000);         // Wait for 1 second       
        }
        if (currentLine.endsWith("GET /D")) {    // GET /D 关闭RGB
          setColor(0, 0, 0);  // Black
        }
        if (currentLine.endsWith("GET /E")) {  // GET /E 直流电机转动
          digitalWrite(motoraPin, LOW);  
          digitalWrite(motorbPin, HIGH);               
        }
        if (currentLine.endsWith("GET /F")) {  // GET /F 直流电机不转
          digitalWrite(motoraPin, LOW);  
          digitalWrite(motorbPin, LOW);                 
        }
        if (currentLine.endsWith("GET /G")) {  // GET /G 打开有源蜂鸣器
          digitalWrite(actbuzzPin, HIGH);                              
        }
        if (currentLine.endsWith("GET /H")) {  // GET /H 关闭无源蜂鸣器
          digitalWrite(actbuzzPin, LOW);                              
        }
        if (currentLine.endsWith("GET /I")) {  // GET /I 无源蜂鸣器播放音乐
          Music();          
        }
        if (currentLine.endsWith("GET /J")) {  // GET /J 舵机转到180°
          myservo.write(180); //旋转到180度
          delay(1000); //延迟1s
        }
        if (currentLine.endsWith("GET /K")) {  // GET /K 舵机转到0°
          myservo.write(0); //旋转到0度
          delay(1000); //延迟1s
        }
      } 
    }
    // 断开连接:
    client.stop();
    Serial.println("client disconnected");
  }
}

void printWifiStatus() {
  // 打印你所连接的网络的SSID:
  Serial.print("SSID: ");
  Serial.println(WiFi.SSID());

  // 打印主控板接收到的IP地址:
  IPAddress ip = WiFi.localIP();
  Serial.print("IP Address: ");
  Serial.println(ip);

  // 打印接收到的信号强度:
  long rssi = WiFi.RSSI();
  Serial.print("signal strength (RSSI):");
  Serial.print(rssi);
  Serial.println(" dBm");
  
  // 在浏览器中打开http://[ip]:
  Serial.print("To see this page in action, open a browser to http://");
  Serial.println(ip);
}

void Music() {
  int noteDuration;  // 创建一个变量noteDuration
  for (int i = 0; i < sizeof(noteDurations); ++i){
      noteDuration = 800/noteDurations[i];
      ledcSetup(LEDC_CHANNEL_4, melody[i]*2, LEDC_TIMER_13_BIT);
      ledcAttachPin(pasbuzzPin, LEDC_CHANNEL_4);
      ledcWrite(LEDC_CHANNEL_4, 50);
      delay(noteDuration * 1.30);  // 延时
  }
}

// Function to set the RGB LED color
void setColor(int red, int green, int blue) {
  ledcWrite(chns[0], red); //共阴极LED，高电平开启LED.
  ledcWrite(chns[1], green);
  ledcWrite(chns[2], blue);
}
